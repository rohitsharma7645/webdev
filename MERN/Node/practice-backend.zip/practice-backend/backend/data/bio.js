
const bioData = [{
  name: "Chandan kumar Nayak",
  bio: "A passionate Full Stack Developer focused on building highly aesthetic, interactive user interfaces and robust, scalable backend systems using modern web technologies.",
  role: "Full Stack Developer"
}];

export default bioData;