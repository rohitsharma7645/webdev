
const projectsData = [
  {
    id: 1,
    title: "Task Manager App",
    description: "A collaborative project management workspace with drag-and-drop kanban boards, active user preferences, and responsive grid layouts.",
    tech: ["React", "CSS3", "JavaScript"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    id: 2,
    title: "Hotstar Clone",
    description: "A high-fidelity video streaming platform interface with dynamic content sliders, category filtering, and optimized CSS layouts.",
    tech: ["HTML5", "Vanilla CSS", "JavaScript"],
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    id: 3,
    title: "Campus Course Hub",
    description: "An educational registry enabling students to search, view descriptions, and enroll dynamically in university courses.",
    tech: ["Node.js", "Express", "MongoDB", "CSS3"],
    liveUrl: "#",
    githubUrl: "#"
  }
];

export default projectsData;