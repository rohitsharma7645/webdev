
const skillsData = [
  "React.js",
  "Node.js",
  "Express.js",
  "JavaScript (ES6+)",
  "Vanilla CSS / CSS3",
  "HTML5 & Semantic Markup",
  "REST APIs",
  "Git & Version Control"
];

export default skillsData;